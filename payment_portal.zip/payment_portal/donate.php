<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">

    <link href="assets/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/css/all.min.css" rel="stylesheet">
    <title>Payment Form</title>
</head>

<body>

    <div id="payment_msg">

    </div>
    <div class="payment_page_wrapper">
        <div class="payment_form_wrapper">
            <form class='payment_form' action="#" method="post">
                <h2>Donate</h2>
                <input type="hidden" name="date" id="dte" value="<?php echo date('Y-m-d'); ?>">
                <h4>Email Address</h4>
                <input required type="email" name="email" id="eml">
                <h4>Full name:</h4>
                <input required type="text" name="fullname" id="fulnm">
                <h4>Amount:</h4>
                <input required type="number" name="amount" id="amnt">
                <input type="submit" value="Submit">
                <a style="display:block;width:100%;text-align: center;" href="index.php"><i class="fas fa-home"></i>Return to homepage</a>
            </form>
        </div>
    </div>

</body>


<script>
    $('.payment_form').submit(function(event) {
        event.preventDefault();
        var date = $('#dte').val();
        var email = $('#eml').val();
        var fullname = $('#fulnm').val();
        var amount = $('#amnt').val();

        var payment_items = {
            email: email,
            date: date,
            fullname: fullname,
            amount: amount
        }
        makePayment(payment_items);
    })


    const makePayment = (items) => {
        fetch('api/donate-api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                email: items['email'],
                fullname: items['fullname'],
                date: items['date'],
                amount: items['amount'],
                username: "admin",
                password: 123
            })
        }).then(function(res) {
            return res.json();
        }).then(function(data) {
            console.log(data);
            alert("Donation was successful");
        }).catch(function(error) {
            alert("Error could not Make Donation");
        })
    }
</script>

</html>