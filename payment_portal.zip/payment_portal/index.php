<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">

    <link href="assets/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Payment Portal</title>
</head>



<body>
    <div class="homepage_container">
        <h1>Payment Portal</h1>
        <div class="homepage_container_item">
            <a href="accrued.php"><i class="fas fa-2x fa-money-bill-wave"></i> Make Payment</a>
            <a href="donate.php"><i class="fas fa-2x fa-donate"></i> Donate</a>
            <a href="transaction_history.php"><i class="fas fa-2x fa-history"></i> Transaction History</a>
            <a href="refund.php"><i class="fas fa-2x fa-undo-alt"></i>  Refund Sale</a>
        </div>
    </div>

</body>

</html>