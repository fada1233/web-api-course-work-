<?php
session_start();
include 'connection.php';
if (isset($_POST['submit'])) 
{
    $studentID = stripcslashes(trim($_POST['studentID']));
    $password = stripcslashes(trim($_POST['password']));
    $sql = "SELECT * FROM student WHERE studentID = '$studentID' AND password = '$password'";
    $sql_exec = mysqli_query($conn, $sql);

    if ($sql_exec && ($sql_fetch = mysqli_fetch_assoc($sql_exec))) {
        $_SESSION['student_id'] = $sql_fetch['studentID'];
        //die($_SESSION['studentt_id']);
        header('location: ../accrued.php');
    } else {
        $_SESSION['error'] = 'Could not Login user';
        header('location: ../login.php');
    }
} else {
    $_SESSION['error'] = 'Could not Login user';
    header('location: ../login.php');
}
?>