<?php
$user = array("user"=>"admin","password"=>123);
$_SERVER['PHP_AUTH_USER'] = $user['user'];
$_SERVER['PHP_AUTH_PW'] = $user['password'];
include "../database/connection.php";
if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header('WWW-Authenticate: Basic realm="My Realm"');
    header('HTTP/1.0 401 Unauthorized');
    exit;
} else {
    //echo "<p>Hello {$_SERVER['PHP_AUTH_USER']}.</p>";
    //echo "<p>You entered {$_SERVER['PHP_AUTH_PW']} as your password.</p>";
    $encoded = file_get_contents('php://input');
    $decoded = json_decode($encoded, true);
    if (isset($decoded)) 
    {
    if($_SERVER['PHP_AUTH_USER'] == $decoded['username'] && $_SERVER['PHP_AUTH_PW'] == $decoded['password'])
    {
        $d_id = $decoded['id'];
        $sql = "UPDATE fees SET status = 1 WHERE id = '$d_id'";
        $sql_query = mysqli_query($conn, $sql);
        if ($sql_query) 
        {
            $msg = "Fees was successfully paid";
            $status = 1;
        } else {
            $msg = "Payment was unsuccessful";
            $status = 0;
        }
        $response[] = array("msg" => $msg, "status" => $status);
        
    }
        echo json_encode($response);
    }

}
?>